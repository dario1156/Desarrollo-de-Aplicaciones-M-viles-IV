var saldo: Double = 0.0
var cuentaInicial: Bool = true
var operacion = true

func hacerDeposito() {
    print("Ingrese la cantidad a depositar:")
    if let deposito = readLine(), let cantidad = Double(deposito) {
        saldo += cantidad
        print("Depósito exitoso. Saldo actual: \(saldo)")

        var otroDeposito = true
        while otroDeposito {
            print("¿Desea realizar otro depósito? (s/S para sí, n/N para no)")
            if let opcion = readLine() {
                switch opcion.lowercased() {
                case "s":
                    otroDeposito = false
                    hacerDeposito()
                case "n":
                    otroDeposito = false
                    otraOperacion()
                default:
                    print("Opción no válida.")
                }
            }
        }

        // Una vez hecho el primer depósito, cambiar el estado de cuentaInicial
        cuentaInicial = false
    } else {
        print("Entrada inválida. Por favor, ingrese un número válido.")
    }
}

func hacerRetiro() {
    if cuentaInicial {
        print("No cuentas con saldo.")
        var otraOperacion = true
        while otraOperacion {
            print("¿Desea realizar otra operación? (s/S para sí, n/N para no)")
            if let opcion = readLine() {
                switch opcion.lowercased() {
                case "s":
                    otraOperacion = false
                    mostrarMenu()
                case "n":
                    otraOperacion = false
                    print("Cerrando sesión de cuenta. ¡Vuelva pronto!")
                    operacion = false
                default:
                    print("Opción no válida.")
                }
            }
        }
    } else {
        print("Ingrese la cantidad a retirar:")
        if let retiro = readLine(), let cantidad = Double(retiro) {
            if saldo > 0 && cantidad <= saldo {
                saldo -= cantidad
                print("Retiro exitoso. Saldo actual: \(saldo)")

                var otroRetiro = true
                while otroRetiro {
                    print("¿Desea realizar otro retiro? (s/S para sí, n/N para no)")
                    if let opcion = readLine() {
                        switch opcion.lowercased() {
                        case "s":
                            otroRetiro = false
                            hacerRetiro()
                        case "n":
                            otroRetiro = false
                            otraOperacion()
                        default:
                            print("Opción no válida.")
                        }
                    }
                }
            } else {
                print("Monto de retiro inválido o saldo insuficiente.")
                otraOperacion()
            }
        } else {
            print("Entrada inválida. Por favor, ingrese un número válido.")
        }
    }
}

func consultarSaldo() {
    print("Su saldo actual es: \(saldo)")
    otraOperacion()
}

func otraOperacion() {
    var continuarOperando = true
    while continuarOperando {
        print("¿Desea continuar con otra operación? (s/S para sí, n/N para no)")
        if let opcion = readLine() {
            switch opcion.lowercased() {
            case "s":
                continuarOperando = false
                mostrarMenu()
            case "n":
                continuarOperando = false
                print("Cerrando sesión de cuenta. ¡Vuelva pronto!")
                operacion = false
            default:
                print("Opción no válida.")
            }
        }
    }
}

func mostrarMenu() {
    print("\n¿Qué operación desea realizar?")
    print("1. Depósito")
    print("2. Retiro")
    print("3. Saldo")
    print("4. Salir")

    if let opcion = readLine(), let eleccion = Int(opcion) {
        switch eleccion {
        case 1:
            hacerDeposito()
        case 2:
            hacerRetiro()
        case 3:
            consultarSaldo()
        case 4:
            operacion = false
            print("Gracias por utilizar nuestros servicios.")
        default:
            print("Opción no válida.")
        }
    } else {
        print("Por favor, ingrese un número correspondiente a la opción deseada.")
    }
}

print("¡Bienvenido al Banco Mexicano!")
mostrarMenu()
