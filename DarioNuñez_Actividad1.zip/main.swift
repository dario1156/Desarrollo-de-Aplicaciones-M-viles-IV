// Definición de la estructura de un artículo
struct Ropa {
    var nombre: String
    var precio: Double
    var stock: Int
}

// Crear una lista de artículos disponibles
var articulos: [Ropa] = [
    Ropa(nombre: "Camisa", precio: 25.99, stock: 10),
    Ropa(nombre: "Pantalón", precio: 39.99, stock: 8),
    Ropa(nombre: "Vestido", precio: 49.99, stock: 5),
    Ropa(nombre: "Chaqueta", precio: 59.99, stock: 3)
]

// Función para mostrar los artículos disponibles
func mostrarArticulos() {
    print("Artículos disponibles:")
    for (index, articulo) in articulos.enumerated() {
        print("\(index + 1). \(articulo.nombre) - Precio: $\(articulo.precio) - Stock: \(articulo.stock)")
    }
}

// Función principal para la interacción con el cliente
func tiendaRopa() {
    var comprando = true

    print("¡Bienvenido a la tienda de ropa!")

    while comprando {
        mostrarArticulos()
        print("\n¿Qué deseas hacer?")
        print("1. Comprar un artículo")
        print("2. Salir")

        if let opcion = readLine(), let eleccion = Int(opcion) {
            switch eleccion {
            case 1:
                print("Ingresa el número del artículo que deseas comprar:")
                if let seleccion = readLine(), let indice = Int(seleccion) {
                    if indice > 0 && indice <= articulos.count {
                        let articuloSeleccionado = articulos[indice - 1]

                        if articuloSeleccionado.stock > 0 {
                            print("Artículo seleccionado: \(articuloSeleccionado.nombre)")
                            print("Precio por unidad: $\(articuloSeleccionado.precio)")

                            print("Ingresa la cantidad que deseas comprar:")
                            if let cantidadStr = readLine(), let cantidad = Int(cantidadStr), cantidad > 0 {
                                if cantidad <= articuloSeleccionado.stock {
                                    let totalPagar = Double(cantidad) * articuloSeleccionado.precio
                                    print("Has comprado \(cantidad) \(articuloSeleccionado.nombre). El total a pagar es: $\(totalPagar)")
                                    articulos[indice - 1].stock -= cantidad
                                } else {
                                    print("Lo sentimos, no hay suficiente stock disponible para esa cantidad.")
                                }
                            } else {
                                print("Cantidad inválida.")
                            }
                        } else {
                            print("Lo sentimos, este artículo está agotado.")
                        }
                    } else {
                        print("Selección inválida.")
                    }
                }
            case 2:
                print("Gracias por visitar la tienda. ¡Vuelve pronto!")
                comprando = false
            default:
                print("Opción no válida.")
            }
        } else {
            print("Por favor, ingresa un número válido.")
        }
    }
}

// Ejecutar la tienda
tiendaRopa()
